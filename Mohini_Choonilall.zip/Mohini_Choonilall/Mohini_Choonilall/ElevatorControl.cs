﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Mohini_Choonilall.Elevator;

namespace Mohini_Choonilall
{
    class ElevatorControl : IElevatorControl
    {
        
        private List<IElevator> elevators; 

        public ElevatorControl(List<IElevator> elevators)
        {
            this.elevators = elevators;
        }

        public IElevator FindNearestElevator(int targetFloor)
        {
            var availableElevators = elevators.Where(elevator => !elevator.IsMoving);
            var nearestElevator = availableElevators.OrderBy(elevator => Math.Abs(elevator.CurrentFloor - targetFloor)).FirstOrDefault();

            return nearestElevator;
        }
    }
}
