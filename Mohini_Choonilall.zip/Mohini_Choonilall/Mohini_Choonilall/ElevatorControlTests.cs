﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;

//[TestClass]
//public class ElevatorControlTests
//{
//    [TestMethod]
//    public void CallElevator_Should_Return_NearestElevator()
//    {
//        // Arrange
//        var elevator1 = new Elevator();
//        var elevator2 = new Elevator();
//        var elevators = new List<Elevator> { elevator1, elevator2 };
//        var elevatorControl = new ElevatorControl(elevators);

//        // Act
//        elevator1.CurrentFloor = 5;
//        elevator2.CurrentFloor = 10;
//        var nearestElevator = elevatorControl.FindNearestElevator(7);

//        // Assert
//        Assert.AreEqual(elevator1, nearestElevator);
//    }

//    [TestMethod]
//    public async Task MoveToFloorAsync_Should_Update_Elevator_CurrentFloor()
//    {
//        // Arrange
//        var elevator = new Elevator();
//        var targetFloor = 5;

//        // Act
//        await elevator.MoveToFloorAsync(targetFloor);

//        // Assert
//        Assert.AreEqual(targetFloor, elevator.CurrentFloor);
//    }

//    // Add more unit tests for various scenarios
//}
