﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mohini_Choonilall
{
    class Building
    {
        private List<Elevator> elevators = new List<Elevator>();
        private int numberOfFloors;

        private Dictionary<int, Queue<int>> floorButtonPresses = new Dictionary<int, Queue<int>>();

        public Building(int numberOfElevators, int numberOfFloors)
        {
            for (int i = 0; i < numberOfElevators; i++)
            {
                elevators.Add(new Elevator());
            }

            for (int i = 1; i <= numberOfFloors; i++)
            {
                floorButtonPresses[i] = new Queue<int>();
            }
        }

        public async Task CallElevatorAsync(int targetFloor, int passengerCount)
        {
            try
            {
                var nearestElevator = FindNearestElevator(targetFloor);

                if (nearestElevator != null)
                {
                    Console.WriteLine($"Calling elevator to floor {targetFloor}");
                    floorButtonPresses[targetFloor].Enqueue(passengerCount);
                    nearestElevator.AddPassengers(passengerCount);
                    await nearestElevator.MoveToFloorAsync(targetFloor);
                    floorButtonPresses[targetFloor].Dequeue();
                    nearestElevator.RemovePassengers(passengerCount);
                    Console.WriteLine($"Passengers have been picked up from floor {targetFloor}");
                }
                else
                {
                    Console.WriteLine("No available elevator at the moment. Please wait.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }


        public void DisplayElevatorStatus()
        {
            // Console.Clear();

            Console.WriteLine();
            Console.WriteLine("Elevator Status:");

            var elevatorStatuses = elevators.Select((elevator, index) =>
                $"Elevator {index + 1} - Floor: {elevator.CurrentFloor}, Moving: {elevator.IsMoving}, Passengers: {elevator.PassengerCount}");

            foreach (var status in elevatorStatuses)
            {
                Console.WriteLine(status);
            }

            Console.WriteLine("\n----------------------------------------");
            Console.WriteLine("Instructions:");
            Console.WriteLine("Enter target floor (1-10) and passenger count to call an elevator.");
            Console.WriteLine("Press Enter to update status.");
            Console.WriteLine("----------------------------------------");

            Console.Write("Press Enter to refresh status...");
            Console.ReadLine();
        }

        private Elevator FindNearestElevator(int targetFloor)
        {
            var availableElevators = elevators.Where(elevator => !elevator.IsMoving);
            var nearestElevator = availableElevators.OrderBy(elevator => Math.Abs(elevator.CurrentFloor - targetFloor)).FirstOrDefault();

            return nearestElevator;
        }

    }
}
