﻿using System.Threading.Tasks;

namespace Mohini_Choonilall
{
    interface IElevator
    {
        int CurrentFloor { get; }
        bool IsMoving { get; }
        int PassengerCount { get; }

        Task MoveToFloorAsync(int targetFloor);
        void AddPassengers(int count);
        void RemovePassengers(int count);
    }
}
