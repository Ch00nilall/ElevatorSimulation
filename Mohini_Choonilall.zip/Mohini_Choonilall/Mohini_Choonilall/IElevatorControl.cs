﻿namespace Mohini_Choonilall
{
    interface IElevatorControl
    {
        IElevator FindNearestElevator(int targetFloor);
    }
}
