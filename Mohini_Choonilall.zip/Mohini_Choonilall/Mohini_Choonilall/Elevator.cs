﻿using System;
using System.Threading.Tasks;

namespace Mohini_Choonilall
{
    class Elevator: IElevator
    {
        public int CurrentFloor { get; private set; }
        public bool IsMoving { get; private set; }
        public int PassengerCount { get; private set; }

        public Elevator()
        {
            CurrentFloor = 1;
            IsMoving = false;
            PassengerCount = 0;
        }

        public async Task MoveToFloorAsync(int targetFloor)
        {
            IsMoving = true;
            if(CurrentFloor> targetFloor)
            {
                Console.WriteLine($"Elevator is moving up from floor {CurrentFloor} to floor {targetFloor}");
            }
            else
            {
                Console.WriteLine($"Elevator is moving down from floor {CurrentFloor} to floor {targetFloor}");
            }
            
            Console.WriteLine($"The elevator is moving");

            await SimulateElevatorMovementAsync(Math.Abs(targetFloor - CurrentFloor));
            CurrentFloor = targetFloor;
            IsMoving = false;

            Console.WriteLine($"Elevator has arrived at floor {CurrentFloor}");
        }

        public void AddPassengers(int count)
        {
            PassengerCount += count;
        }

        public void RemovePassengers(int count)
        {
            PassengerCount -= count;
        }

        private async Task SimulateElevatorMovementAsync(int floors)
        {
            // Simulate elevator movement asynchronously (I/O-bound operation)
            await Task.Delay(floors * 1000);
        }
    }
}