﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mohini_Choonilall
{
    class Program
    {

        static async Task Main(string[] args)
        {
            int numberOfElevators = 5; 
            int numberOfFloors = 10;

            Building building = new Building(numberOfElevators, numberOfFloors);

            while (true)
            {
                building.DisplayElevatorStatus();
                try
                {
                    Console.Write("Enter target floor (1-10): ");
                    int targetFloor = int.Parse(Console.ReadLine());

                    Console.Write("Enter passenger count: ");
                    int passengerCount = int.Parse(Console.ReadLine());

                    await building.CallElevatorAsync(targetFloor, passengerCount);

                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

        }
    }

}
